# RuleBot

A small rule-based chatbot built with plain HTML, CSS and JavaScript. No frameworks, no backend, no API calls — just a dictionary lookup and a UI that makes it look more impressive than it actually is under the hood.

## What is this, exactly?

RuleBot is what it says on the tin: a **deterministic** chatbot. Type the same message twice, get the exact same response both times. No randomness, no "thinking," no model weights — just an `if this, then that` lookup table dressed up in a dark, sci-fi-ish UI.

I built this mostly to make a point to myself about the difference between **deterministic AI** (rule-based, predictable, fully explainable — this) and **probabilistic AI** (LLMs like ChatGPT, where the same prompt can give you a different answer every time). RuleBot's own "about ai" command actually explains this distinction if you ask it.

So no, this isn't trying to compete with an actual language model. It's closer to the chatbots from the early 2000s — just with nicer CSS.

## Features

- Typing indicator with a short delay before responding (purely cosmetic, makes it feel less instant/robotic)
- Quick-reply chips so you don't have to type common commands
- A basic guardrail system — blocks a small list of flagged words before they ever reach the response logic
- Session ending — typing `exit`, `quit`, or `stop` ends the chat and disables the input
- Message counter and timestamps on every bubble
- Fully self-contained — one HTML file, zero dependencies besides two Google Fonts

## How it actually works

The whole "brain" of this bot is one JavaScript object:

```js
const knowledgeBase = {
  "hello": "Hey there! I am RuleBot...",
  "joke": "Why do programmers prefer dark mode?...",
  // ...
};
```

When you send a message, it goes through three steps:

1. **`sanitize()`** — lowercases and trims whatever you typed
2. **`isSafe()`** — checks it against a small banned-words list
3. **`getResponse()`** — looks up the cleaned text directly in `knowledgeBase`

If your exact phrase isn't a key in that object, you get the fallback "I don't understand that yet" message. There's no fuzzy matching, no NLP, no similarity scoring — it's literally a dictionary lookup. That's the whole trick.

`"EXIT"` is used as a special marker value in the dictionary (for `exit`, `quit`, `stop`) that the `sendMessage()` function checks for separately, to know when to lock the input field.

## Tech stack

- **HTML/CSS** — no Tailwind, no Bootstrap, all hand-written
- **Vanilla JavaScript** — no React, no jQuery, nothing
- **Google Fonts** — Orbitron (the blocky header font) and Rajdhani (body text)

That's it. No `npm install`, no build step, no `node_modules`.

## Running it

Open the HTML file in any browser. That's the entire setup process. If you want to host it somewhere, any static file host works — there's nothing server-side to configure.

## Known limitations (being honest here)

- It only responds to **exact phrase matches**. "hello" works, "helloo" or "hii there" won't — there's no typo tolerance or synonym handling.
- The banned-word filter is a plain substring check, so it's pretty naive — it could theoretically flag a harmless word that happens to contain a banned substring.
- Chat history doesn't persist. Refresh the page, it's gone. (No `localStorage` used here on purpose, to keep the file dependency-free and avoid mixing in storage logic that wasn't part of the original scope.)
- It's not "AI" in the machine-learning sense at all — calling it that is mostly for the contrast/teaching angle, not a technical claim.

## Ideas if I ever come back to this

- Basic fuzzy matching (Levenshtein distance or similar) so close-enough phrases still match
- A few more knowledge base entries — right now it's a fairly small set
- A light/dark theme toggle
- Maybe persist chat history with `localStorage` if this ever needs to survive a refresh

## Credits

Fonts via Google Fonts. Emoji used as icons instead of an icon library, mainly to keep this a single, dependency-free file.
