import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# load the job roles dataset
def load_dataset(filepath="raw_skills.csv"):
    try:
        data = pd.read_csv(filepath)
        print(f"Dataset loaded successfully. Total job roles: {len(data)}")
        return data
    except FileNotFoundError:
        print(f"[ERROR] Could not find '{filepath}'. Check the file path!")
        exit()


# ask the user for their skills
def get_user_input():
    print("\n" + "~" * 60)
    print("  TECH STACK RECOMMENDER / Find Your Ideal Career Path")
    print("~" * 60)
    print("\nEnter at least 3 skills or interests you have.")
    print("Example: Python, Cloud Computing, Automation")

    user_input = input("\nYour skills (comma separated): ")
    skills_list = [skill.strip() for skill in user_input.split(",") if skill.strip()]

    if len(skills_list) < 1:
        print("[WARNING] No skills entered. Using default sample skills.")
        skills_list = ["Python", "Cloud Computing", "Automation"]

    user_profile_string = " ".join(skills_list)
    print(f"\n Captured profile: {skills_list}")
    return user_profile_string


# convert jobs + user profile into TF-IDF vectors (same vocabulary space)
def build_vector_space(job_descriptions, user_profile):
    all_documents = list(job_descriptions) + [user_profile]

    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(all_documents)

    job_vectors = tfidf_matrix[:-1]
    user_vector = tfidf_matrix[-1]

    return job_vectors, user_vector, vectorizer


# compare the user vector against every job vector
def calculate_similarity_scores(job_vectors, user_vector):
    similarity_scores = cosine_similarity(user_vector, job_vectors)
    return similarity_scores.flatten()


# sort by score and keep only the top matches
def get_top_recommendations(data, scores, top_n=3):
    data = data.copy()
    data["similarity_score"] = scores
    sorted_data = data.sort_values(by="similarity_score", ascending=False)
    return sorted_data.head(top_n)


# print the final recommendations
def display_recommendations(top_results):
    print("\n" + "~" * 60)
    print("  YOUR TOP CAREER MATCHES")
    print("~" * 60)

    if top_results["similarity_score"].max() == 0:
        print("\n[COLD START] No matching skills found in our database.")
        print("Showing TRENDING roles instead (fallback strategy):\n")
        top_results = top_results.head(3)

    rank = 1
    for _, row in top_results.iterrows():
        match_percent = row["similarity_score"] * 100
        print(f"\n  {rank}. {row['job_role']}")
        print(f"     Match Score : {match_percent:.1f}%")
        print(f"     Key Skills  : {row['required_skills']}")
        rank += 1

    print("\n" + "═" * 60)


# run the full pipeline end to end
def run_recommender():
    data = load_dataset("raw_skills.csv")
    user_profile = get_user_input()

    job_vectors, user_vector, vectorizer = build_vector_space(
        data["required_skills"], user_profile
    )

    scores = calculate_similarity_scores(job_vectors, user_vector)
    top_results = get_top_recommendations(data, scores, top_n=3)
    display_recommendations(top_results)


if __name__ == "__main__":
    run_recommender()