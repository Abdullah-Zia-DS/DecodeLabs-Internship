import { useState } from "react";
import {
  Target,
  Sparkles,
  RotateCcw,
  TrendingUp,
  ArrowRight,
  Loader2,
  AlertTriangle,
  ListChecks,
  Cpu,
  Trophy,
} from "lucide-react";

// the backend (tech_stack_recommender.py) must be running for this to work:
//   python tech_stack_recommender.py
const API_URL = "http://localhost:5000/recommend";

const suggestionChips = [
  "Python",
  "React",
  "Cloud Computing",
  "Machine Learning",
  "Cybersecurity",
  "UI Design",
  "Kubernetes",
  "SQL",
];

const howItWorks = [
  {
    icon: ListChecks,
    title: "1. Enter your skills",
    text: "Type in at least 3 skills or interests — anything from Python to UI Design.",
  },
  {
    icon: Cpu,
    title: "2. TF-IDF + cosine matching",
    text: "Your profile is compared against every job role's required skills using the same algorithm under the hood.",
  },
  {
    icon: Trophy,
    title: "3. Get your top 3 matches",
    text: "Ranked by match score, with the exact skills each role is looking for.",
  },
];

export default function TechStackRecommender() {
  const [skillsInput, setSkillsInput] = useState("");
  const [capturedProfile, setCapturedProfile] = useState([]);
  const [results, setResults] = useState(null);
  const [coldStart, setColdStart] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function findMatches(overrideText) {
    const skillsToSend = overrideText ?? skillsInput;
    setLoading(true);
    setError("");

    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ skills: skillsToSend }),
      });

      if (!response.ok) throw new Error("Request failed");

      const data = await response.json();
      setCapturedProfile(data.captured_profile);
      setColdStart(data.cold_start);
      setResults(data.results);
    } catch (err) {
      setError(
        "Couldn't reach the recommender backend. Make sure tech_stack_recommender.py is running on port 5000."
      );
    } finally {
      setLoading(false);
    }
  }

  function handleKeyDown(e) {
    if (e.key === "Enter") findMatches();
  }

  function addChip(chip) {
    const current = skillsInput
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (!current.includes(chip)) {
      setSkillsInput([...current, chip].join(", "));
    }
  }

  function reset() {
    setResults(null);
    setColdStart(false);
    setError("");
  }

  return (
    <div className="min-h-screen w-full" style={{ background: "linear-gradient(160deg, #2b1a14 0%, #1a100c 55%, #140c08 100%)" }}>
      {/* Header */}
      <header
        className="flex items-center justify-between px-6 md:px-12 py-4"
        style={{ background: "linear-gradient(135deg, #5c3a26, #3d2517)", borderBottom: "1px solid #6b4226" }}
      >
        <div className="flex items-center gap-3">
          <div
            className="flex items-center justify-center w-10 h-10 rounded-xl shrink-0"
            style={{ background: "linear-gradient(135deg, #c9854f, #8a5530)" }}
          >
            <Target size={18} className="text-[#fbf3ea]" />
          </div>
          <div className="text-[15px] font-semibold text-[#fbf3ea] flex items-center gap-1.5">
            Tech Stack Recommender <Sparkles size={13} className="text-[#e0a86f]" />
          </div>
        </div>
        <div className="text-[12px] hidden sm:block" style={{ color: "#cba47e" }}>
          TF-IDF + Cosine Similarity matching
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 md:px-10 py-12 md:py-16">
        {/* Hero / search */}
        <section className="text-center mb-14">
          <h1 className="text-3xl md:text-4xl font-bold mb-3" style={{ color: "#fbf3ea" }}>
            Find your ideal career path
          </h1>
          <p className="text-[14px] md:text-[15px] mb-8 max-w-xl mx-auto" style={{ color: "#cba47e" }}>
            Tell us at least 3 skills or interests, and we'll match you against real tech job roles.
          </p>

          {error && (
            <div
              className="flex items-start gap-2 text-[12px] px-4 py-3 rounded-xl mb-5 max-w-xl mx-auto text-left"
              style={{ background: "#f7e2c8", color: "#92400e", border: "1px solid #e3b07a" }}
            >
              <AlertTriangle size={14} className="shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-2.5 max-w-xl mx-auto">
            <input
              type="text"
              value={skillsInput}
              onChange={(e) => setSkillsInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={loading}
              placeholder="e.g. Python, Cloud Computing, Automation"
              className="flex-1 px-5 py-3.5 text-[14px] rounded-full outline-none disabled:opacity-60"
              style={{ background: "#fbf3ea", color: "#3d2517", border: "1px solid #d8b894" }}
            />
            <button
              onClick={() => findMatches()}
              disabled={loading}
              className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-full text-[14px] font-medium transition disabled:opacity-70 shrink-0"
              style={{ background: "linear-gradient(135deg, #c9854f, #8a5530)", color: "#fbf3ea" }}
            >
              {loading ? (
                <>
                  <Loader2 size={15} className="animate-spin" /> Matching...
                </>
              ) : (
                <>
                  Find My Matches <ArrowRight size={15} />
                </>
              )}
            </button>
          </div>

          <div className="flex flex-wrap gap-2 justify-center mt-5 max-w-2xl mx-auto">
            {suggestionChips.map((chip) => (
              <button
                key={chip}
                onClick={() => addChip(chip)}
                className="text-[12px] px-3 py-1.5 rounded-full transition"
                style={{ background: "rgba(201,133,79,0.12)", color: "#e0a86f", border: "1px solid rgba(224,168,111,0.3)" }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(201,133,79,0.22)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(201,133,79,0.12)")}
              >
                + {chip}
              </button>
            ))}
          </div>
        </section>

        {/* Results */}
        {results ? (
          <section>
            <div className="flex items-center justify-between mb-6">
              <div>
                <div className="text-[15px] font-semibold" style={{ color: "#fbf3ea" }}>
                  Your top career matches
                </div>
                <div className="text-[12px]" style={{ color: "#a9824f" }}>
                  Based on: {capturedProfile.join(", ")}
                </div>
              </div>
              <button
                onClick={reset}
                className="flex items-center gap-1.5 text-[12.5px] px-4 py-2 rounded-full shrink-0 transition"
                style={{ background: "#f1e2cd", color: "#7a4824" }}
              >
                <RotateCcw size={13} /> Search again
              </button>
            </div>

            {coldStart && (
              <div
                className="text-[12.5px] px-4 py-3 rounded-xl mb-5"
                style={{ background: "#f7e2c8", color: "#92400e", border: "1px solid #e3b07a" }}
              >
                No close matches found for those skills — showing trending roles instead.
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {results.map((job, i) => (
                <div
                  key={job.job_role}
                  className="flex flex-col px-5 py-5 rounded-2xl animate-[fadeIn_0.35s_ease-out]"
                  style={{ background: "#f1e2cd", border: "1px solid #e3c79f" }}
                >
                  <div className="flex items-center justify-between mb-3">
                    <span
                      className="flex items-center justify-center w-7 h-7 rounded-full text-[12px] font-semibold shrink-0"
                      style={{ background: "#8a5530", color: "#fbf3ea" }}
                    >
                      {i + 1}
                    </span>
                    <div className="flex items-center gap-1 text-[12.5px] font-medium" style={{ color: "#8a5530" }}>
                      <TrendingUp size={13} /> {job.match_score}%
                    </div>
                  </div>

                  <div className="text-[15px] font-semibold mb-2.5" style={{ color: "#3d2517" }}>
                    {job.job_role}
                  </div>

                  <div className="w-full h-1.5 rounded-full mb-3.5" style={{ background: "#e3c79f" }}>
                    <div
                      className="h-1.5 rounded-full transition-all duration-700"
                      style={{ width: `${job.match_score}%`, background: "linear-gradient(90deg, #c9854f, #8a5530)" }}
                    />
                  </div>

                  <div className="flex flex-wrap gap-1.5 mt-auto">
                    {job.required_skills.split(" ").map((skill, idx) => (
                      <span
                        key={idx}
                        className="text-[10.5px] px-2 py-0.5 rounded-full"
                        style={{ background: "#fbf3ea", color: "#7a4824", border: "1px solid #e3c79f" }}
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>
        ) : (
          /* How it works — fills the page before a search happens */
          <section className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {howItWorks.map(({ icon: Icon, title, text }) => (
              <div
                key={title}
                className="px-5 py-6 rounded-2xl"
                style={{ background: "rgba(251,243,234,0.06)", border: "1px solid rgba(216,184,148,0.25)" }}
              >
                <div
                  className="flex items-center justify-center w-10 h-10 rounded-xl mb-4"
                  style={{ background: "linear-gradient(135deg, #c9854f, #8a5530)" }}
                >
                  <Icon size={18} className="text-[#fbf3ea]" />
                </div>
                <div className="text-[14px] font-semibold mb-1.5" style={{ color: "#fbf3ea" }}>
                  {title}
                </div>
                <div className="text-[12.5px] leading-relaxed" style={{ color: "#cba47e" }}>
                  {text}
                </div>
              </div>
            ))}
          </section>
        )}
      </main>
    </div>
  );
}