# Tech Stack Recommender — Project Documentation

## DecodeLabs Industrial Training Kit — AI Project 3

---

## 1. Project Overview

```
Name      : Tech Stack Recommender
Type      : AI Recommendation Logic (Content-Based Filtering)
Goal      : Map a user's skills to the best matching career path
Input     : 3+ skills typed by the user
Output    : Top 3 recommended job roles with match percentage
```

This project is a digital matchmaker. A user types in skills they
know (e.g. Python, Cloud, Automation) and the system mathematically
compares those skills against a catalog of job roles, returning the
3 best matching careers — exactly the same core logic used by
Netflix, Amazon, and Spotify recommendation engines.

---

## 2. Files in This Project

```
tech_stack_recommender.py   -> main program (run this file)
raw_skills.csv               -> dataset of 15 job roles + their skills
README.md                    -> this documentation
```

---

## 3. Technologies and Libraries Used

| Library | Purpose |
|---|---|
| `pandas` | Load and manage the job roles dataset |
| `scikit-learn` (TfidfVectorizer) | Convert text into TF-IDF weighted vectors |
| `scikit-learn` (cosine_similarity) | Measure angle-based similarity between vectors |

Install with:
```bash
pip install pandas scikit-learn
```

Run with:
```bash
python tech_stack_recommender.py
```

---

## 4. The IPO Model (Core Architecture)

Every recommendation engine follows this 3-phase structure:

```
INPUT   (User State)       -> capturing the user's skills
PROCESS (Similarity Logic) -> TF-IDF + Cosine Similarity math
OUTPUT  (Top-N List)       -> Top 3 ranked recommendations
```

This is the "logic skeleton" that all recommendation systems are
built on top of, regardless of how advanced they get later.

---

## 5. The 4-Step Ranking Pipeline

The actual code executes 4 sequential steps:

```
STEP 1 — INGESTION
Function : get_user_input()
Job      : Capture the user's raw skill input as text,
           clean it (sanitize), and prepare it for processing.

STEP 2 — SCORING
Function : build_vector_space() + calculate_similarity_scores()
Job      : Convert all text into TF-IDF vectors, then calculate
           a Cosine Similarity score between the user and
           EVERY job role in the dataset.

STEP 3 — SORTING
Function : get_top_recommendations()
Job      : Arrange all job roles from highest similarity score
           to lowest similarity score.

STEP 4 — FILTERING
Function : get_top_recommendations() (top_n parameter)
Job      : Cut the sorted list down to only the Top 3 results,
           preventing "Choice Overload" for the user.
```

---

## 6. Why Content-Based Filtering (Not Collaborative)

```
Collaborative Filtering -> needs a large history of OTHER users'
                            behavior ("users who liked X also liked Y")
                            Not possible here — no historical data exists

Content-Based Filtering -> needs only the ITEM'S OWN features
                            (the skills listed for each job role)
                            Works immediately, even with zero users
```

This project uses Content-Based Filtering exclusively because it
allows the engine to function correctly from day one without
needing thousands of past users.

---

## 7. Vector Mapping — Turning Words into Numbers

Computers cannot understand words like "Python" or "Cloud" directly.
Every skill must be converted into a number inside a shared
vocabulary space before any comparison is possible.

```
Example:
Vocabulary = [Python, Cloud, Automation]

User picks Python and Automation
Vector created = [1, 0, 1]
                   ↑  ↑  ↑
              Python Cloud Automation
```

**Critical rule used in this project:** the wording in `raw_skills.csv`
and the wording the user types must align closely (e.g. "Cloud
Computing" matches "Cloud Computing", not "Cloud Tech"). The
TfidfVectorizer in scikit-learn automatically builds this shared
vocabulary from both the dataset and the user input combined.

---

## 8. TF-IDF — Smarter Than Simple 1s and 0s

A simple binary vector (1 = has skill, 0 = doesn't) treats every
skill as equally important. TF-IDF fixes this by weighting skills
based on how common or rare they are.

```
TF  (Term Frequency)
    = how often a skill appears in one job description
    = more mentions -> more important to THAT job

IDF (Inverse Document Frequency)
    = log(Total job roles / job roles containing this skill)
    = penalizes common skills found in almost every job
    = rewards rare, specific skills found in very few jobs

TF-IDF = TF × IDF
    = a skill that is frequent AND rare gets the highest score
```

In code, this is handled in a single line using:
```python
vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform(all_documents)
```

---

## 9. Why Cosine Similarity Instead of Euclidean Distance

```
Euclidean Distance -> measures straight-line distance
                       FAILS when comparing a short user profile
                       (3 skills) against a long job description
                       (10 skills) because it is sensitive to size

Cosine Similarity   -> measures the ANGLE between two vectors
                       IGNORES size/length completely
                       Only cares about DIRECTION (which skills
                       matter), making it ideal for this project
```

```
Score interpretation used in this project:
1.0  -> perfect match (identical skill direction)
0.5  -> partial overlap
0.0  -> no shared skills at all (orthogonal vectors)
```

This is implemented with:
```python
similarity_scores = cosine_similarity(user_vector, job_vectors)
```

---

## 10. Handling the Cold Start Problem

The Cold Start problem occurs when a user's skills do not match
ANY job role in the dataset — resulting in similarity scores of
all zeros.

```
Fix implemented in this project: TRENDING FALLBACK

If the highest similarity score equals 0,
the system automatically falls back to showing
a default set of popular roles instead of an empty list.
```

This is handled inside `display_recommendations()`:
```python
if top_results["similarity_score"].max() == 0:
    print("[COLD START] No matching skills found...")
```

---

## 11. Sample Output

**Input:** `Python, Cloud Computing, Automation`

```
1. Network Engineer        — Match Score: 52.7%
2. System Administrator    — Match Score: 52.7%
3. Cloud Architect         — Match Score: 46.2%
```

**Input (unrelated skills):** `Cooking, Painting, Gardening`

```
[COLD START] No matching skills found in our database.
Showing TRENDING roles instead (fallback strategy)
```

---

## 12. Key Concepts Summary Table

| Concept | What It Does | Where It's Used in Code |
|---|---|---|
| IPO Model | Structures the whole pipeline | Overall program flow |
| Content-Based Filtering | Matches using item features only | `build_vector_space()` |
| Vector Mapping | Converts text to numbers | `TfidfVectorizer` |
| TF-IDF | Weighs rare vs common skills | `build_vector_space()` |
| Cosine Similarity | Measures angle-based match | `calculate_similarity_scores()` |
| 4-Step Pipeline | Ingestion-Scoring-Sorting-Filtering | All 4 main functions |
| Cold Start Handling | Fallback when no match found | `display_recommendations()` |

---

## 13. How to Extend This Project

```
- Add more job roles to raw_skills.csv for a richer catalog
- Allow users to "rate" recommendations to build feedback data
- Add a simple GUI using Streamlit for live web demo
- Combine with collaborative filtering once enough users exist
- Add weighted skills (let user mark "expert" vs "beginner")
```
