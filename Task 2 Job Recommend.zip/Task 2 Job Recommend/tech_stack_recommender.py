import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # allows the frontend (running on a different port) to call this API


# load the job roles dataset
def load_dataset(filepath="raw_skills.csv"):
    try:
        data = pd.read_csv(filepath)
        print(f"Dataset loaded successfully. Total job roles: {len(data)}")
        return data
    except FileNotFoundError:
        print(f"[ERROR] Could not find '{filepath}'. Check the file path!")
        exit()


# convert jobs + user profile into TF-IDF vectors (same vocabulary space)
def build_vector_space(job_descriptions, user_profile):
    all_documents = list(job_descriptions) + [user_profile]

    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(all_documents)

    job_vectors = tfidf_matrix[:-1]
    user_vector = tfidf_matrix[-1]

    return job_vectors, user_vector, vectorizer


# compare the user vector against every job vector
def calculate_similarity_scores(job_vectors, user_vector):
    similarity_scores = cosine_similarity(user_vector, job_vectors)
    return similarity_scores.flatten()


# sort by score and keep only the top matches
def get_top_recommendations(data, scores, top_n=3):
    data = data.copy()
    data["similarity_score"] = scores
    sorted_data = data.sort_values(by="similarity_score", ascending=False)
    return sorted_data.head(top_n)


# load the dataset once when the server starts (not on every request)
job_data = load_dataset("raw_skills.csv")


# API endpoint the frontend calls -- same pipeline, just returns JSON instead of printing
@app.route("/recommend", methods=["POST"])
def recommend():
    body = request.get_json(silent=True) or {}
    raw_skills = body.get("skills", "")

    skills_list = [skill.strip() for skill in raw_skills.split(",") if skill.strip()]
    if len(skills_list) < 1:
        skills_list = ["Python", "Cloud Computing", "Automation"]

    user_profile = " ".join(skills_list)

    job_vectors, user_vector, vectorizer = build_vector_space(
        job_data["required_skills"], user_profile
    )

    scores = calculate_similarity_scores(job_vectors, user_vector)
    top_results = get_top_recommendations(job_data, scores, top_n=3)

    is_cold_start = bool(top_results["similarity_score"].max() == 0)

    results = []
    for _, row in top_results.iterrows():
        results.append({
            "job_role": row["job_role"],
            "required_skills": row["required_skills"],
            "match_score": round(float(row["similarity_score"]) * 100, 1),
        })

    return jsonify({
        "captured_profile": skills_list,
        "cold_start": is_cold_start,
        "results": results,
    })


if __name__ == "__main__":
    app.run(port=5000, debug=True)